<?php include("functions.php");?>

<!DOCTYPE html>
<?php include("navigation.php") ?>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet"  href="css/log1n.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        .header {
            background: #41B3A3;
        }
        button[name=register_btn] {
            background: #41B3A3;
        }
    </style>
</head>

<body>
    
    <form name= "loginForm" method="post" action="login.php">
    <div class="header">
        <h2>Login</h2>
        </div>
        <?php echo display_error(); ?>
        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" >
           
        </div>
        <div class="input-group">
          
            <label>Password</label>
            <input type="password" name="password">
        </div>
        <br>
        <div class="g-recaptcha" data-sitekey="6LcNj7gjAAAAALL3LviSQPoAfpp4CMkFzj28Cbg5"></div>
        <div class="input-group">
            <button type="submit" class="btn" name="login_btn">Login</button>
        </div>
    </div>
    </form> 

    

</body>
</html>
