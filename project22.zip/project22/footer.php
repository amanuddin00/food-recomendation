

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
   <link href="css/footer.css" rel="stylesheet" >

<style>
   #slidesh {
  margin: 10px auto;
  position: relative;
  width: 190px;
  height: 190px;
  padding: 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
}

#slidesh > div {
  position: absolute;
  top: 10px;
  left: 10px;
  right: 10px;
  bottom: 10px;
}


</style>

</head>
<body>
    <footer>
    <Center><h4>Scan Me Now!</h4></center>
        <div id="slidesh">
            <?php
            $db = mysqli_connect('localhost', 'root', '', 'webproject');
                $querry = $db->query("SELECT * FROM qrTable");
                while($resl = $querry->fetch_array()) {
                ?>
                <img src="Admin/qrcodeImage/<?=$resl['qr_image']?>" alt="" width="190px">
                <?php
                }
                ?>
        </div>
        <center><p class="text-center">&copy; Copyright 2022 - Amanuddin and Friends.  All rights reserved.</p></center>
</footer>
<script>
$("#slidesh > div:gt(0)").hide();

setInterval(function() {
  $('#slidesh > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#slidesh');
}, 3000);
</script>
</body>
</html>