<!DOCTYPE html>


<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: right;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
</style>
</head>
<body>

<ul>
  <li><a href="../functions.php?logout=1">Logout</a></li>
  <li><a href="log.php">log</a></li>
  <li><a href="feedback.php">Feedback</a></li>
  <li><a href="addAdmin.php">Add Staff</a></li>
  <li><a href="listAdmin.php">Update User</a></li>
  <li><a href="generateQR.php">Generate Qr Code</a></li>
  <li><a href="adminhome.php">Dashboard</a></li>
</ul>

</body>
</html>


