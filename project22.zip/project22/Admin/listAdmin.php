<?php 
//session_start();

include('../functions.php');
include("adminnav.php");

if($_SESSION["login"] != 1){
    echo "<script>alert('You need to login first')</script>";
    header('Location: logout.php');
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
   
    <link rel="stylesheet" href="../css/update.css">

</head>
  <body>
  <center> <h1>Admin List</h1> </center>
  <table>
                <thead>
                    
                    <th>Username</th>
                    <th>Email</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php
                        $mysqli_page = $db->query("SELECT * from admin where user_type = 'admin'");
                                      
                        $id;
                        if ($mysqli_page->num_rows > 0){
                            while($row_page = $mysqli_page->fetch_array(MYSQLI_ASSOC)){
                                echo "<tr>";
                                echo "<td>";
                                echo $row_page['username'];
                                echo "</td><td>";
                                echo $row_page['email'];
                                $id = $row_page['id'];
                                echo "</td><td><a href='updateAdmin.php?edit=$id'>Edit</a></td>";
                                echo "<td><a href='listAdmin.php?delete= $id' class='del_btn' >Delete</a></td>";
                                echo "</tr>";
                            }
                        }
                    
                    ?>

                </tbody>
            </table>
            <br>
            <table>
            <center> <h1>Staff List</h1> </center>
                <thead>
                    
                    <th>Username</th>
                    <th>Email</th>
                    <th>Action</th>
                </thead>
                <tbody>
                <?php echo display_error(); ?>
                    <?php
                        $mysqli_page = $db->query("SELECT * from admin where user_type = 'staff'");
                                      
                        $id;
                        if ($mysqli_page->num_rows > 0){
                            while($row_page = $mysqli_page->fetch_array(MYSQLI_ASSOC)){
                                echo "<tr>";
                                echo "<td>";
                                echo $row_page['username'];
                                echo "</td><td>";
                                echo $row_page['email'];
                                $id = $row_page['id'];
                                echo "</td><td><a href='updateAdmin.php?edit=$id' class='edit_btn' >Edit</a></td>";
                                echo "<td><a href='listAdmin.php?delete= $id' class='del_btn' >Delete</a></td>";
                                echo "</tr>";
                            }
                        }
                    
                    ?>

                </tbody>
            </table>
  </body>
</html>