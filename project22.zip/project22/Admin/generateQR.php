<?php 
include('../functions.php') ;
include ("adminnav.php") ;
include("phpqrcode/qrlib.php");

if($_SESSION["login"] != 1){
    echo "<script>alert('You need to login first')</script>";
    header('Location: logout.php');
  }

if(isset($_POST['addQr']))
{
    $folderTemp = "qrcodeImage/";

    $Link_name = $_POST["linkName"];
    $link_url = $_POST["linkUrl"];

    $img = $Link_name.".png";



    $quality = "H";
    
    $size = 6;
    $padding = 0;

    QRCode::png($link_url,$folderTemp.$img,$quality,$size,$padding);


    $querry = $db->query("UPDATE qrTable SET qr_name = '$Link_name',qr_link = '$link_url',qr_image = '$img' WHERE idqrcode = '1'");

    if($querry)
    {
        header('location:adminhome.php');
    }else{
   
    echo "gagal";
    die($con->error);
    }
}
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Qr Code</title>
    <link rel="stylesheet" type="text/css" href="../css/styleadmin.css">
    <style>
        .header {
            background: #41B3A3;
        }
        button[name=addQr] {
            background: #41B3A3;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Generate Qr Code</h2>
    </div>
    
    <form method="post" action="generateQR.php">

        <?php echo display_error(); ?>

        <div class="input-group">
            <label>Link Name</label>
            <input type="text" name="linkName">
        </div>
        <div class="input-group">
            <label>Link</label>
            <input type="text" name="linkUrl">
        </div>
        <div class="input-group">
    <button type="submit" class="btn" name="addQr"> Save </button>
        </div>
    </form>
</body>
</html>
