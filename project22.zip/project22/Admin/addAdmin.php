<?php 
include('../functions.php') ;
include ("adminnav.php") ;
if($_SESSION["login"] != 1){
    echo "<script>alert('You need to login first')</script>";
    header('Location: logout.php');
  }
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Staff</title>
    <link rel="stylesheet" type="text/css" href="../css/styleadmin.css">
    <style>
        .header {
            background: #41B3A3;
        }
        button[name=register_btn] {
            background: #41B3A3;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Add Staff</h2>
    </div>
    
    <form method="post" action="addAdmin.php">

        <?php echo display_error(); ?>

        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo $username; ?>">
        </div>
        <div class="input-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $email; ?>">
        </div>
        <div class="input-group">
            <label>User type</label>
            <select name="user_type" id="user_type" >
                <option value="admin">Admin</option>
                <option value="staff">Staff</option>
                
            </select>
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password_1">
        </div>
        <div class="input-group">
            <label>Confirm password</label>
            <input type="password" name="password_2">
        </div>
        <div class="input-group">
    <button type="submit" class="btn" name="register_btn"> Add </button>
        </div>
    </form>
</body>
</html>
