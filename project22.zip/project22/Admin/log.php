<?php 
include('../functions.php');
include("adminnav.php");
if($_SESSION["login"] != 1){
    echo "<script>alert('You need to login first')</script>";
    header('Location: logout.php');
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Page</title>
   
    <link rel="stylesheet" href="../css/update.css">

</head>
  <body>
  <center> <h1>User Log</h1> </center>
  <table>
                <thead>
                    
                    <th>Username</th>
                    <th>Email</th>
                    <th>User Time Login</th>
                    <th>Activity</th>
                </thead>
                <tbody>
                    <?php
                        $mysqli_page = $db->query("SELECT * FROM log INNER JOIN admin ON log.id =admin.id order by logid ;");
                                      
                        $id;
                        if ($mysqli_page->num_rows > 0){
                            while($row_page = $mysqli_page->fetch_array(MYSQLI_ASSOC)){
                                echo "<tr>";
                                echo "<td>";
                                echo $row_page['username'];
                                echo "</td><td>";
                                echo $row_page['email'];
                                echo "</td><td>";
                                echo $row_page['time'];
                                echo "</td><td>";
                                echo $row_page['typelog'];
                                echo "</tr>";
                            }
                        }
                    
                    ?>

                </tbody>
            </table>
            <br>
        
  </body>
</html>