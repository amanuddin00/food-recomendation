<?php
include("../functions.php");
include("adminnav.php");
if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
   
    <link rel="stylesheet" href="../css/update.css">

</head>
  <body>
  <center> <h1>Feedback</h1> </center>
    <table>
                <tbody>
                <?php
                       
                        // Attempt select query execution
                        $sql = "SELECT * FROM  users";
                        if($result = mysqli_query($db, $sql)){
                            if(mysqli_num_rows($result) > 0){
                                echo "<table>";
                                    echo "<tr>";
                                        echo "<th>Id</th>";
                                        echo "<th>Username</th>";
                                       
                                        echo "<th>Message</th>";
                                    echo "</tr>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['username'] . "</td>";
                                    
                                        
                                        echo "<td>" . $row['message'] . "</td>";
                                    echo "</tr>";
                                }
                                echo "</table>";
                                // Free result set
                                mysqli_free_result($result);
                            } else{
                                echo "No records matching your query were found.";
                            }
                        } else{
                            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                        }
                        
                        // Close connection
                        mysqli_close($db);
                        ?>

                </tbody>
            </table>
  </body>
</html>