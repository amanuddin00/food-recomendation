<?php
include("../functions.php");
include("adminnav.php");
if($_SESSION["login"] != 1){
    echo "<script>alert('You need to login first')</script>";
    header('Location: logout.php');
  }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="../css/styleadmin.css">
    <style>
        .header {
            background: #41B3A3;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Home Page</h2>
    </div>
    <div class="content">
        <!-- notification message -->
        <?php if (isset($_SESSION['success'])) : ?>
            <div class="error success" >
                <h3>
                    <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']);
                    ?>
                </h3>
            </div>
        <?php endif ?>
        <!-- logged in user information -->
        <div class="profile_info">
            <div>
                <?php  if (isset($_SESSION['admin'])) : ?>
                <strong><?php echo $_SESSION['admin']['username']; ?></strong>

                <small>
    <I style="color: #888;">(<?php echo ucfirst($_SESSION['admin']['user_type']); ?>)</i> 
    <br>
    
                </small>

                <?php endif ?>
            </div>
        </div>
    </div>
</body>
</html>
