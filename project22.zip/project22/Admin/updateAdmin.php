<?php

 include('../functions.php') ;
include ("adminnav.php") ;
if($_SESSION["login"] != 1){
    echo "<script>alert('You need to login first')</script>";
    header('Location: logout.php');
  }
$id = $_GET['edit'];
if($id == $_SESSION['admin']['id'] || $_SESSION['admin']['user_type'] == "admin"){
 
}else{
    header('Location: listAdmin.php');
}


?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Admin</title>
    <link rel="stylesheet" type="text/css" href="../css/styleadmin.css">
    <style>
        .header {
            background: #41B3A3;
        }
        button[name=register_btn] {
            background: #41B3A3;
        }
    </style>
</head>
<body>
<?php 
    $id = $_GET['edit'];
   
    $sql = "SELECT * From admin where id = '$id' ";
    $Result = mysqli_query($db,$sql);
?>
    
    <div class="header">
        <h2>Update Admin</h2>
    </div>
    
    <form method="post" action="updateAdmin.php">

        <?php echo display_error(); ?>
        <?php 
        if (mysqli_num_rows($Result)> 0 ){
            while($row = mysqli_fetch_assoc($Result)){

        ?>
        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo $row['username']; ?>">
        </div>

        <div class="input-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $row['email']; ?>">
        </div>
        <div class="input-group">
            <label>User type</label>
            <select name="user_type" id="user_type" >
                <option value="admin">Admin</option>
                <option value="Staff">Staff</option>         
            </select>
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password_1">
        </div>
        <div class="input-group">
            <label>Confirm password</label>
            <input type="password" name="password_2">
            <input type="hidden" name="id" value="<?php echo $id;?>">
        </div>
            
        <?php
        }
    }
    else{
        echo "problem";
    }
    ?>
    
        <div class="input-group">
    <button type="submit" class="btn" name="updatebtn"> Update </button>
        </div>
    </form>
</body>
</html>
