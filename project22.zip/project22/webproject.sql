-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2023 at 11:13 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `user_type`, `password`) VALUES
(44, 'sds', 'sad@gmail.com', 'admin', 'b424b75d47faf3c3d2f65a63655ccadef542c0582e62e89110e4e019a469caef311b9ebcf5621a96beefae3def0a578c10d3ccb088f8faef0d62ddd1fec656bb'),
(45, 'amanuddin1', 'amanuddinamry123@gmail.com', 'admin', 'b424b75d47faf3c3d2f65a63655ccadef542c0582e62e89110e4e019a469caef311b9ebcf5621a96beefae3def0a578c10d3ccb088f8faef0d62ddd1fec656bb'),
(46, 'aman', 'aman@gmail.com', 'staff', 'b424b75d47faf3c3d2f65a63655ccadef542c0582e62e89110e4e019a469caef311b9ebcf5621a96beefae3def0a578c10d3ccb088f8faef0d62ddd1fec656bb');

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `logid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `typelog` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`logid`, `id`, `time`, `typelog`) VALUES
(67, 44, '2022-12-30 10:16:35', 'login'),
(68, 44, '2022-12-30 10:21:35', 'delete amanuddin1'),
(69, 44, '2022-12-30 10:22:47', 'delete amanuddin'),
(70, 44, '2022-12-30 10:22:49', 'delete aman'),
(71, 44, '2022-12-30 10:22:49', 'delete syahir'),
(72, 45, '2022-12-30 10:24:35', 'login'),
(73, 46, '2022-12-30 10:25:45', 'login'),
(74, 45, '2023-01-01 08:52:29', 'login'),
(75, 45, '2023-01-01 10:07:11', 'login'),
(76, 45, '2023-01-01 10:17:48', 'login'),
(77, 45, '2023-01-01 10:59:46', 'login'),
(78, 46, '2023-01-01 11:03:22', 'login'),
(79, 46, '2023-01-01 11:03:49', 'login'),
(80, 46, '2023-01-01 11:05:59', 'login'),
(81, 46, '2023-01-01 11:06:35', 'login'),
(82, 45, '2023-01-01 11:11:33', 'login');

-- --------------------------------------------------------

--
-- Table structure for table `qrtable`
--

CREATE TABLE `qrtable` (
  `idqrcode` int(40) NOT NULL,
  `qr_name` varchar(100) NOT NULL,
  `qr_link` varchar(100) NOT NULL,
  `qr_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `qrtable`
--

INSERT INTO `qrtable` (`idqrcode`, `qr_name`, `qr_link`, `qr_image`) VALUES
(1, 'google doc', 'https://docs.google.com/document/d/1yIyysMmtgP1FimNX1-CvflFZ4nzSOfKYwglPuASnjf4/edit', 'google doc.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `phone`, `message`) VALUES
(1, 'aman', 'amanuddinamry123@gmail.com', '2147483647', 'testing'),
(2, 'fatin', 'fatin@gmail.com', '1111111111', 'testing'),
(3, 'a', 'amanuddinamry123@gmail.com', '0', 'a'),
(7, 'qw', 'amanuddinamry123@gmail.com', '0', 'a'),
(11, 'amanuddin', 'amanuddinamry123@gmail.com', '11', 'aman'),
(12, 'aman', 'amanuddinamry123@gmail.com', '011-790-3878', 'a'),
(13, 'asa', 'amanuddinamry123@gmail.com', '011-6077-3878', 'aman'),
(14, 'sa', 'amanuddinamry123@gmail.com', '019-0987-1231', 'a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`logid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `qrtable`
--
ALTER TABLE `qrtable`
  ADD PRIMARY KEY (`idqrcode`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `qrtable`
--
ALTER TABLE `qrtable`
  MODIFY `idqrcode` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`id`) REFERENCES `admin` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
