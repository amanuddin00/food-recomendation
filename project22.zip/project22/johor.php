<?php include 'navigation.php' ?>


<!DOCTYPE html> 
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Johor</title>
    <link rel="stylesheet" href="css/state.css"/>

</head>
<body>
    <div class="title">
            <h1>Johor Traditional Food</h1>
    </div>
    
    <fieldset>
    <table>
        <tr>
            <legend>Johor Laksa</legend>
            <td rowspan="2">
            <img src="img/Johorlaksa.jpg" width="200px" height="200px"></td>
            <td><h3>Laksa is a popular dish, not only in Johor, but in Malaysia in general. But did you know that almost every state in Malaysia adds its own unique twist to this beloved dish? While most laksa dishes use either rice noodles or egg noodles, Johor laksa uses a more unique ingredient: spaghetti! 
                <br>Apart from the unique noodle choice, Johor laksa also comes with a slightly thicker and richer gravy. The dish is usually topped with shredded vegetables and meat, and a dash of freshly-squeezed lime to bring everything together. 
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Kacang Pool</legend>
            <td rowspan="2">
            <img src="img/KacangPool.jpg" width="200px" height="200px"></td>
            <td><h3>Kacang Pool is said to have originated from an Egyptian dish, Ful medames, cooked using fava beans. The beans are mashed and cooked with mince meat and spices. 
                <br>It is usually served with a sunny side up egg and a slice of thick toast. Chopped up onions, calamansi lime and slices of green chilli adds a little more zing to the dish.
                <br>The Larkin Fire Station food court is the famous spot to find this dish, though you can also find it at the hipster cafe Cupchai in Bandar Baru Uda and Kilang Bateri. 
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Asam Pedas</legend>
            <td rowspan="2">
            <img src="img/Asampedas.jpg" width="200px" height="200px"></td>
            <td><h3>Asam Pedas is a term for sour and spicy stew, and is famous in Melaka and Johor. The Johorean Asam Pedas is noted for its use of kesum leaves – also known as ‘Vietnamese coriander’ – black pepper and has a thicker gravy which is bright red in color. 
                <br>The Asam Pedas gravy is usually cooked with either chicken or seafood such as stingray or skate, red snapper and other varieties of fish. Typically, it is served with white rice alongside other dishes.
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Nasi Briyani Gam</legend>
            <td rowspan="2">
            <img src="img/Nasibriyanigam.jpg" width="200px" height="200px"></td>
            <td><h3>You might be thinking: Briyani isn’t all that special,it can probably find this anywhere in Malaysia. While you’re not wrong, Johor’s version of the dish, briyani gam, is a little different.  
                <br>For most biryani dishes, the rice is usually cooked separately from the other ingredients and assembled together before serving. However, to cook the perfect biryani gam, the fragrant basmati rice is cooked together with the other ingredients in the same pot. This allows the oils and fragrances of the other ingredients to seep into the rice, giving it an extra layer of aroma. It also keeps the rice moist and fluffy.  
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Mee Rebus</legend>
            <td rowspan="2">
            <img src="img/MeeRebus.jpg" width="200px" height="200px"></td>
            <td><h3>Mee Rebus is a yellow egg noodle dish, served with a gravy made from sweet potatoes and spices. It is usually served with boiled eggs, calamansi limes, fried tofu, bean sprouts, and fried shallots. 
                <br>The famous Johor Mee Rebus Haji Wahid includes a garnishing of fried dried shrimp mixed with flour. 
            </h3></td>
        </tr>
    </table>
    </fieldset>
</body>
</html>

