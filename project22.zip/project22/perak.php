


<!DOCTYPE html> 
<?php include 'navigation.php' ?>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perak</title>
    <link rel="stylesheet" href="css/state.css"/>

</head>
<body>
    <div class="title">
            <h1>Perak Traditional Food</h1>
    </div>
    
    <fieldset>
    <table>
        <tr>
            <legend>Gulai Kemahang</legend>
            <td rowspan="2">
            <img src="img/Gulaikemahang.jpg" width="200px" height="200px"></td>
            <td><h3>Kemahang is a plant originating from a family of yam. It is a wild yam tree that can give it a sense of itching if it does not work properly. The trunk or stem leather should be removed before being cut along three inches.
                <br>It should be boiled or soaked with salt water, stuck before cooking to reduce itching. Flowering fringe should not be taken as it is usually a panacea. Gulai Kemahang was once a meal of the Sultan who had been polluted when visiting one of the villages in Lenggong.
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Rendang Tok</legend>
            <td rowspan="2">
            <img src="img/Rendangtok.jpg" width="200px" height="200px"></td>
            <td><h3>Rendang Tok actually said to have originated from Kampung Pisang Batu Gajah, Perak, which later spread to most districts in Perak. It is the traditional Malay dish with its own special taste and flavor without any addition of preservatives and artificial flavorings. Uniquely, Rendang Tok is still prepares using traditional methods using the wood stove. 
                <br>Rendang Tok is normally served as a side dish, which is eaten with Lemang, rice, Ketupat Palas, bread, or you can even eat it on its own. This dish is said to be carried on from generation to generation since ancient times because the cooking method involves cooking spices and traditional ingridients. Rendang Tok name is also said to be used in ancient times as it is cooked by parents at that time and the cooking methods are so dry and black. That's the origin of the name.
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Kelamai</legend>
            <td rowspan="2">
            <img src="img/Kelamai.jpg" width="200px" height="200px"></td>
            <td><h3>Kelamai is a traditional food of the Rawa community and is a hereditary heritage. This cake can be found in Batang Padang Gopeng Perak area, most of which are local communities. It looks like dodol where it uses ingredients such as glutinous flour, brown sugar, coconut milk, kerisik, oil and white sugar. Its manufacturing method is as sweet as it is also cooked in bamboo and then baked. 
                <br>The preparation process takes up to 3 days for the ingredients to be absorbed before it is inserted into the bamboo to burn. The appropriate bamboo selection is also very important to produce a really delicious cocktail.
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Daging Masak Hitam</legend>
            <td rowspan="2">
            <img src="img/Dagingmasakhitam.jpeg" width="200px" height="200px"></td>
            <td><h3>This is a traditional Malay cuisine of Lenggong in Hulu Perak. Previously, this dish was often used as a menu during weddings or served to specialists and special guests. This dish usually uses beef, but it can also be replaced with buffalo, goat or chicken.  
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Renja Ubi Kayu</legend>
            <td rowspan="2">
            <img src="img/Penjaubikayu.jpg" width="200px" height="200px"></td>
            <td><h3>The ubi of the tub sounds quite peculiar. However, if you are curious, this dish is among forget by everyone in Perak, this was the traditional dishes in Perak. Previously, this dish is often eaten in the evening.Perfect match of this dishes was coffee. It is very easy to prepare. Using tapioca, brown sugar, corn flour, pandanus and water leaves are enough to boost the flavor of this dish. Wooden casserole is boiled before mixing with other ingredients. 
            </h3></td>
        </tr>
    </table>
    </fieldset>
</body>
</html>

