



<?php
  include'navigation.php'
  ?>

<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="css/about.css"/>
    <title>About Us</title>
</head>
<html>
<body>
<div id="about">
    
    <div class="picture">
        <img src="img/A4.png" style="width:1405px;height:700px">
    </div>
 
    <div class="description">
    <h1>About Us</h1>
    <br>
        <p>
            Food Recommendation Blog is a website that present the recommended foods in each 
            Malaysian state. 
            This blog will help Malaysian tourists and citizens find the best food options. 
            It's because the food recommendation blog included a description of the recommended 
            food as well as its location. Next, this blog also provides a secure website to 
            the owner of the website because it has a few security components. Besides that, 
            this website is user-friendly because it is accessible to all user.
        </p>
        <br>
        <br>
        <h1>Our Team</h1>
        
    <p>
        <br>
        AMANUDDIN BIN AMRY <br>
        DI200039 <br>
        <br>
        PUN KAH YIEN <br>
        AI200235 <br>
        <br>
        ROSHAN EASHWAR A/L MURALITHARAN <br>
        DI200043 <br>
        <br>
        FATIN NADIA BINTI MOHD YUSOF <br>
        AI200026 <br>
        <br>
        MUHAMMAD LUQMAN BIN KHIRULNIZAM<br>
        AI200178<br>
    </p>
    </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>


