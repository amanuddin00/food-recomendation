<!DOCTYPE html>
<html>
<head>

</head>
<body>



<footer>
  <p>Author: Hege Refsnes<br>
  <a href="mailto:hege@example.com">hege@example.com</a></p>
</footer>

</body>
</html>
