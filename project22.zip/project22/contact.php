<?php

$servername = "localhost";
$username = "username";
$conn = mysqli_connect('localhost', 'root', '','webproject');
 
 if (isset($_POST["submit"])) {
  $username = $_POST["username"];
  $email = $_POST["email"];
  $phone = $_POST["phone"];
  $message = $_POST["message"];

  $sql="INSERT INTO users(username, email, phone,message) VALUES ('$username','$email','$phone','$message')";

  if (mysqli_query($conn, $sql)) {
    header("location: contact.php");}
  mysqli_close($conn);
}
  include'navigation.php'
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Form</title>
    <link rel="stylesheet" href="css/contact.css" />
    
  </head>
  <body>
    
    <div class="container">
      <span class="big-circle"></span>
      <img src="img/shape.png" class="square" alt="" />
      <div class="form"> 
        <div class="contact-info">
          <h3>You may contact us when you:</h3><br>
            <ul>
              <li><h4>Correct the information for the page.</h4></li><br>
              <li><h4>Recommand us a good restaurant.</h4></li><br>
              <li><h4>Promote your own restaurant.</h4></li><br>
            </ul>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="" method="post" autocomplete="off">
            <h3 class="title">Contact us</h3>
            <div class="input-container">
              <label for="name"></label>
              <input type="text" name="username" class="input" placeholder="Enter Username" required/>
              <span>Username</span>
            </div>
            <div class="input-container">
              <input type="email" name="email" class="input" placeholder="Enter Email(Ex:webdev@gmail.com)"required/>
              <label for="email"></label>
              <span>Email</span>
            </div>
            <div class="input-container">
              <input type="tel" name="phone" class="input" placeholder="Enter Phone No (Ex:123-456-7890)" pattern="[0-9]{3}-[0-9]{4}-[0-9]{4}"
       required>
              <label for="phone"></label>
              <span>Phone</span>
            </div>
            <div class="input-container textarea">
              <textarea name="message" class="input"placeholder="Enter Message" required></textarea>
              <label for="message"></label>
              <span>Message</span>
            </div>
            <input type="submit" name="submit" value="Send" class="btn"/>
          </form>
        </div>
      </div>
    </div>

    <script src="contact.js"></script>
    <?php include 'footer.php'; ?>
  </body>
</html>
