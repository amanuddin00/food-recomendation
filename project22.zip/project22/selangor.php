<?php include'navigation.php' ?>


<!DOCTYPE html> 
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Selangor</title>
    <link rel="stylesheet" href="css/state.css"/>
 
</head>
<body>
    <div class="title">
            <h1>Selangor Traditional Food</h1>
    </div>
    
    <fieldset>
    <table>
        <tr>
            <legend>Pecal</legend>
            <td rowspan="2">
            <img src="img/Pecal.jpg" width="200px" height="200px"></td>
            <td><h3>Pecal is a common appetiser that can be found just about anywhere in Selangor. Known to be a traditional Javanese salad that merely consists of vegetables topped with a mouth-watering peanut sauce that can also be served with Ketupator Lontong.  
                <br>he preparation in making Pecalis extremely simple so you can easily try it at home at any time! The key ingredients to prepare this dish are peanuts or groundnuts for the gravy or which we call ‘kuah’, tofu, bean sprout, long beans and cucumber. 
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Nasi Ambeng</legend>
            <td rowspan="2">
            <img src="img/Nasiambeng.jpg" width="200px" height="200px"></td>
            <td><h3>Nasi Ambeng is usually served in a form of a platter which can be shared with four to five people per serving. It consists of a variety of food choices that will just blow your mind. 
                <br>When it comes to preparing this Javanese-Malay dish, you should not miss out on its side dishes which are chicken, fried noodles, long beans, sambal tempeaccompanied by white rice that is served in banana leaf! In Selangor, Nasi Ambeng is normally served at festivals or large gatherings or locally known as ‘Kenduri’.
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Sambal Taun</legend>
            <td rowspan="2">
            <img src="img/Sambaltaun.jpg" width="200px" height="200px"></td>
            <td><h3>Known as Sambal Taun or Sambal Tahun, this unique dish is famous among Selangorians. It originates from the Javanese early settlers and has become a traditional food of Selangor ever since. This dish is said to be spicy because of the amount of chili used in its preparation. 
                <br>Hence, the name sambal. Here in Selangor, the protein is taken from cow skin but it is commonly switch to either clams, cow lungs or even anchovies, according to one’s preference.
                <br>Other ingredients needed to complete this one of a kind main dish are red onions, garlic, shrimp paste, coconut milk, oil, tamarind paste, a pinch of salt and sugar. 
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Wadai Kipeng</legend>
            <td rowspan="2">
            <img src="img/Wadaikipeng.jpg" width="200px" height="200px"></td>
            <td><h3>In the tongue of the Banjar people, ‘Wadai’ predominantly means‘Kuih’, while ‘Kipeng’ is refers to pieces. Back in the day, it has been traditionally practiced by the Banjar community to plate up Wadai Kipengon their Thanksgiving ceremony!
                <br>It goes without saying, to prepare this porridge-like dessert, the must-have ingredients are glutinous rice flour, coconut, palm sugar, granulated sugar and some pandan leaves! This is a perfect sweet ending to your meal.  
            </h3></td>
        </tr>
    </table>
    </fieldset>
<br>
    <fieldset>
    <table>
        <tr>
            <legend>Bahulu Kemboja</legend>
            <td rowspan="2">
            <img src="img/Bahulukemboja.jpg" width="200px" height="200px"></td>
            <td><h3>Bahulu Kembojacan be served whenever you like, be it for breakfast, or even during teatime, well you choose! Having its own speciality, this kuih is sold widely but it is undeniably though to find one that taste as original as the Selangor one today. 
                <br>You can always try making one at home and you may be surprised at what good of a cook you are! To maintain the uniqueness and moisture of the kuih, the ingredients needed are original pandan essence straight from its leaves, wheat flour, rice flour, some coconut milk, eggs, sesame seeds for topping and of course, sugar and salt to give taste!
            </h3></td>
        </tr>
    </table>
    </fieldset>
</body>
</html>

