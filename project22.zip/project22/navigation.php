
<!DOCTYPE html>
<html>

<head>
  <style>

    *{
    padding: 0;
    margin: 0;
    }

    body{
      box-sizing: border-box;
      background-color: white;
    }

    .topnav{
      position: fixed;
    	z-index: 10;
	    left: 0;
	    right: 0;
	    top: 0;
	    font-family: 'Montserrat', sans-serif;
	    padding: 0 5%;
      
	    background-color: white;
    }

    .subtop{
      float: right;
	    padding: 0;
	    margin: 0;
	    width: 60%;
	    height: 100%;
	    display: flex;
	    justify-content: space-around;
	    align-items: center;
    }

    .topnav ul{
      display: inline-flex;
      list-style: none;
      color: black;
    }

    .topnav ul li{
      width: 120px;
      margin: 15px;
      padding: 15px;
    }

    .topnav ul li a{
      text-decoration: none;
      color: black;
    }

    .topnav ul li:hover{
      background-color: whitesmoke;
      border-radius: 3px;
    }

    .substate{
      display: none;
    }

    .topnav ul li:hover .substate{
      display: block;
      position: absolute;
      background: whitesmoke;
      margin-top: 15px;
      margin-left: 15px;
    }

    .topnav ul li:hover .substate ul{
      display: block;
      margin: 10px;
    }


  </style>
</head>
<body>

<div class="topnav">
<img class="logo-img" src="img/FoodLogo.png" width="80" height="80" ALT="align box" ALIGN=left>
  <ul class="subtop">
  <li><a href="index.php">Home</a></li>
  <li><a href="#">State</a>
    <div class="substate">
        <ul>
          <li><a href="johor.php">Johor</a></li>
          <li><a href="perak.php">Perak</a></li>
          <li><a href="selangor.php">Selangor</a></li>  
        </ul>
    </div>
    
  </li>
  <li><a href="aboutus.php">About Us</a></li>
  <li><a href="contact.php">Contact Us</a></li>
  <li><a href="login.php">Login</a></li>
  
  </ul>
</div>

</body>
</html>
