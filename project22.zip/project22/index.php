<!DOCTYPE html>

<?php

include 'navigation.php';

?>

<head>
    <link href="css/styleindex.css" rel="stylesheet">
    <title>Food Recomendation</title>
    <style>
        p {text-align: center;}
    </style>
</head>
<html>
<body>
            <div>

                <div class="slideshow-container">

                    <div class="mySlides fade">
                    <div class="numbertext">1 / 3</div>
                    <img src="img/laksajohor.jpg" style="width:100%" height="550px">
                    
                </div>

                <div class="mySlides fade">
                    <div class="numbertext" style="background-color: black;">Mee Rebus</div>
                        <img src="img/MeeRebus.jpg" style="width:100%" height="550px">
                        
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">3 / 3</div>
                    <img src="img/F3.png" style="width:100%" height="550px">
                    
                </div>
            </div>

            <br>

            <div style="text-align:center">
            <span class="dot"></span> 
            <span class="dot"></span> 
            <span class="dot"></span> 
            </div>

            </div>

<script src="js/index.js"></script>

        <center><h1>Malaysia</h1>
        <br>
        <div class="row" >
            <div class="col-md-9 col-xs-12 wow fadeINup" style="max-width:1000px">
                <p>For hundreds of years, Malaysia has served as a rich melting pot of south-east Asian
                    culture and ethnicities. Malaysia’s welcoming and tolerant society has long since embraced
                    these multi-ethnic influences and Malaysian food is no exception. Influences from
                    Chinese, Indian, Thai, Arab and ethnic Malay cooking give Malaysian food culture a truly
                    unique edge over other national cuisines and will immediately captivate the taste buds.
                    The result is vibrant dishes with richness, spice, succulence but also freshness. Nowhere
                    else can you find the thick heaviness of Indian curry influences alongside dishes like
                    Cantonese style steam Pau and traditional Malay Keropok Lekor.
                    <br>
                    It’s not just Malaysian cooking that’s unique.
                    The open and vibrant communal eating culture of night markets, cafes, Mamak’s and hawker stalls has 
                    also played a part in shaping Malaysian street food as a national scene. 
                    The culture around convenient and cheap meals has produced a more bite-sized form of Malaysian food, 
                    which is accessible and equally delicious!<p>
                <br>   
            </div>
            <img src="img/malaysiaculture.jpg" width="1000px" height="550px">
        </div>  
        <br> 
        <div class="row">
        <div class="col-md-9 col-xs-12 wow fadeINup" style="max-width:1000px" >
        <p>With such a diverse population of citizens, it is essential to first note the importance that religious beliefs play in the country’s culinary identity. 
            With the majority population being ethnic Malay, most of which being devout Muslin may only consume ‘halal’ (meaning permissible) food that adheres to Islamic law. 
            This has led to a vast majority of dishes being modified to conform to halal guidelines, opening a wider range of cuisine to the Muslim market. 
            Meanwhile, amongst both the Indian and Chinese communities, Buddhism is a significant faith with practising Bud.The social aspect of dining is a huge part of Malaysian culture and in big cities like Kuala Lumpur or Penang, street food is an especially mouth-watering spectacle. 
            Eating culture is very much a 24 hour a day pattern where food outlets serve up tasty quick dishes for a reasonable price, with Indian Mamaks making up the later hour offerings with their near 24-hour service. 
            The open-air street food culture is so popular in Malaysia because it allows Malaysians to have a choice of eating what they want and when they want.<p>
            <br>
            <img src="img/food.jpg" width="1000px" height="550px">  
        </div>
    </div>
    </center>
    <?php include 'footer.php'; ?>
</body>
</html>

